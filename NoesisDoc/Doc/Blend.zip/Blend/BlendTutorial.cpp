#pragma warning(disable: 4275)
#pragma warning(disable: 4251)


#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/TypeId.h>
#include <NsCore/Package.h>
#include <NsDrawing/Color.h>
#include <NsDrawing/Thickness.h>
#include <NsDrawing/CornerRadius.h>
#include <NsGui/FrameworkPropertyMetaData.h>
#include <NsGui/Application.h>
#include <NsGui/Window.h>
#include <NsGui/Border.h>
#include <NsGui/Canvas.h>
#include <NsGui/Slider.h>
#include <NsGui/RadioButton.h>
#include <NsGui/UserControl.h>
#include <NsGui/SolidColorBrush.h>
#include <NsGui/UIElementData.h>
#include <NsGui/Brushes.h>
#include <NsGui/Rectangle.h>
#include <NsGui/Nullable.h>
#include <NsGui/Binding.h>
#include <NsGui/BindingOperations.h>
#include <NsGui/VisualTreeHelper.h>


using namespace Noesis;
using namespace Noesis::Core;
using namespace Noesis::Gui;


////////////////////////////////////////////////////////////////////////////////////////////////////
class BlendTutorialApp: public Application
{
    NS_IMPLEMENT_INLINE_REFLECTION(BlendTutorialApp, Application)
    {
        NsMeta<TypeId>("BlendTutorial.App");
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
class BlendTutorialColorSelector: public UserControl
{
public:
    SolidColorBrush* GetColor() const
    {
        return GetValue< Ptr<SolidColorBrush> >(ColorProperty).GetPtr();
    }
    void SetColor(SolidColorBrush* color)
    {
        SetValue< Ptr<SolidColorBrush> >(ColorProperty, color);
    }

public:
    static const Gui::DependencyProperty* ColorProperty;

protected:
    /// From DependencyObject
    //@{
    void OnInit()
    {
        ParentClass::OnInit();

        mR = NsStaticCast<Slider*>(FindName("R")); 
        NS_ASSERT(mR != 0);
        mG = NsStaticCast<Slider*>(FindName("G"));
        NS_ASSERT(mG != 0);
        mB = NsStaticCast<Slider*>(FindName("B"));
        NS_ASSERT(mB != 0);
        mA = NsStaticCast<Slider*>(FindName("A"));
        NS_ASSERT(mA != 0);
    }

    NsBool OnPropertyChanged(const DependencyPropertyChangedEventArgs& args)
    {
        NsBool handled = ParentClass::OnPropertyChanged(args);

        if (!handled && args.prop == ColorProperty)
        {
            SolidColorBrush* color = static_cast<const Ptr<SolidColorBrush>*>(args.newValue)->GetPtr();
            UpdateSliders(color);
            return true;
        }

        return handled;
    }
    //@}

private:
    void Slider_ValueChanged(BaseComponent* sender, const RoutedPropertyChangedEventArgs<NsFloat32>& e)
    {
        SolidColorBrush* colorBrush = GetColor();
        if (colorBrush == 0 || colorBrush->IsFrozen())
        {
            Ptr<SolidColorBrush> color = *new SolidColorBrush();
            SetColor(color.GetPtr());
        }

        UpdateColor(mR->GetValue(), mG->GetValue(), mB->GetValue(), mA->GetValue());
    }

    void UpdateColor(NsFloat32 r, NsFloat32 g, NsFloat32 b, NsFloat32 a)
    {
        GetColor()->SetColor(Drawing::Color(r / 255.0f, g / 255.0f, b / 255.0f, a / 255.0f));
    }

    void UpdateSliders(SolidColorBrush* color)
    {
        const Drawing::Color& c = color->GetColor();
        mR->SetValue(c.GetRedF() * 255.0f);
        mG->SetValue(c.GetGreenF() * 255.0f);
        mB->SetValue(c.GetBlueF() * 255.0f);
        mA->SetValue(c.GetAlphaF() * 255.0f);
    }

private:
    Slider* mR;
    Slider* mG;
    Slider* mB;
    Slider* mA;

    NS_IMPLEMENT_INLINE_REFLECTION(BlendTutorialColorSelector, UserControl)
    {
        NsMeta<TypeId>("BlendTutorial.ColorSelector");

        NsProp("Color", &BlendTutorialColorSelector::GetColor, &BlendTutorialColorSelector::SetColor);
        NsFunc("Slider_ValueChanged", &BlendTutorialColorSelector::Slider_ValueChanged);

        NsString source("Gui/Tutorials/Blend/ColorSelector.xaml");

        Ptr<UIElementData> data = NsMeta<UIElementData>(TypeOf<SelfClass>());
        data->RegisterProperty< Ptr<SolidColorBrush> >(ColorProperty, "Color",
            FrameworkPropertyMetadata::Create(*new Ptr<SolidColorBrush>, FrameworkOptions_None));
        data->OverrideMetadata<NsString>(UserControl::SourceProperty, "Source",
            FrameworkPropertyMetadata::Create(source, FrameworkOptions_None));
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
const DependencyProperty* BlendTutorialColorSelector::ColorProperty;

////////////////////////////////////////////////////////////////////////////////////////////////////
class BlendTutorialMainWindow: public Window
{
protected:
    /// From DependencyObject
    //@{
    void OnInit()
    {
        ParentClass::OnInit();

        mContainerBorder = NsStaticCast<Border*>(FindName("ContainerBorder"));
        NS_ASSERT(mContainerBorder != 0);

        mContainerCanvas = NsStaticCast<Canvas*>(FindName("ContainerCanvas"));
        NS_ASSERT(mContainerCanvas != 0);

        mLeft = NsStaticCast<Slider*>(FindName("LeftValue"));
        NS_ASSERT(mLeft != 0);

        mTop = NsStaticCast<Slider*>(FindName("TopValue"));
        NS_ASSERT(mTop != 0);

        mWidth = NsStaticCast<Slider*>(FindName("WidthValue"));
        NS_ASSERT(mWidth != 0);

        mHeight = NsStaticCast<Slider*>(FindName("HeightValue"));
        NS_ASSERT(mHeight != 0);

        mFill = NsStaticCast<RadioButton*>(FindName("FillRadioButton"));
        NS_ASSERT(mFill != 0);

        mColorSelector = NsStaticCast<BlendTutorialColorSelector*>(FindName("ColorSelectorControl"));
        NS_ASSERT(mColorSelector != 0);
    }
    //@}

private:
    void AddButton_Click(const Ptr<BaseComponent>& sender, const RoutedEventArgs& e)
    {
        ClearSelection();

        Ptr<Brush> fill = NsStaticCast<Ptr<Brush> >(Brushes::Red()->Clone());
        Ptr<Brush> stroke = NsStaticCast<Ptr<Brush> >(Brushes::Transparent()->Clone());

        mSelectedRectangle = *new Rectangle();
        mSelectedRectangle->Init();
        mSelectedRectangle->SetFill(fill.GetPtr());
        mSelectedRectangle->SetStroke(stroke.GetPtr());
        mSelectedRectangle->SetStrokeThickness(5.0f);

        mLeft->SetValue(0.0f);
        mTop->SetValue(0.0f);
        mWidth->SetValue(100.0f);
        mHeight->SetValue(100.0f);
        Ptr<SolidColorBrush> color = NsStaticCast<Ptr<SolidColorBrush> >(Brushes::Red()->Clone());
        mColorSelector->SetColor(color.GetPtr());

        BindSelection();

        mContainerCanvas->GetChildren()->Add(mSelectedRectangle.GetPtr());

        SetSelection();

        e.handled = true;
    }

    void RemoveButton_Click(const Ptr<BaseComponent>& sender, const RoutedEventArgs& e)
    {
        if (mSelectedRectangle)
        {
            UIElementCollection* children = mContainerCanvas->GetChildren();
            children->Remove(mSelectedRectangle.GetPtr());
            children->Remove(mSelectionBorder.GetPtr());

            mSelectedRectangle.Reset();
            mSelectionBorder.Reset();
        }

        e.handled = true;
    }

    void RadioButton_Checked(const Ptr<BaseComponent>& sender, const RoutedEventArgs& e)
    {
        if (mSelectedRectangle)
        {
            if (mFill->GetIsChecked().GetValue())
            {
                Ptr<Brush> stroke = NsStaticCast<Ptr<Brush> >(mColorSelector->GetColor()->Clone());
                mSelectedRectangle->SetStroke(stroke.GetPtr());
                mColorSelector->SetColor(NsStaticCast<SolidColorBrush*>(mSelectedRectangle->GetFill()));

                BaseComponent* source = mColorSelector;
                Ptr<Binding> binding = *new Binding("Color", source);
                BindingOperations::SetBinding(mSelectedRectangle.GetPtr(), Shape::FillProperty,
                    binding.GetPtr());
            }
            else
            {
                Ptr<Brush> fill = NsStaticCast<Ptr<Brush> >(mColorSelector->GetColor()->Clone());
                mSelectedRectangle->SetFill(fill.GetPtr());
                mColorSelector->SetColor(NsStaticCast<SolidColorBrush*>(
                    mSelectedRectangle->GetStroke()));

                BaseComponent* source = mColorSelector;
                Ptr<Binding> binding = *new Binding("Color", source);
                BindingOperations::SetBinding(mSelectedRectangle.GetPtr(), Shape::StrokeProperty,
                    binding.GetPtr());
            }
        }

        e.handled = true;
    }
    
    void ContainerBorder_PreviewMouseLeftButtonDown(BaseComponent* sender, const MouseButtonEventArgs& e)
    {
        HitTestResult hr = VisualTreeHelper::HitTest(mContainerBorder,
            mContainerBorder->PointFromScreen(e.position));

        Rectangle* newSelection = NsDynamicCast<Rectangle*>(hr.visualHit.GetPtr());
        if (mSelectedRectangle != newSelection)
        {
            ClearSelection();

            mSelectedRectangle.Reset(newSelection);

            if (mSelectedRectangle)
            {
                mLeft->SetValue(Canvas::GetLeft(mSelectedRectangle.GetPtr()));
                mTop->SetValue(Canvas::GetTop(mSelectedRectangle.GetPtr()));
                mWidth->SetValue(mSelectedRectangle->GetWidth());
                mHeight->SetValue(mSelectedRectangle->GetHeight());
                mColorSelector->SetColor(mFill->GetIsChecked().GetValue() ?
                    NsStaticCast<SolidColorBrush*>(mSelectedRectangle->GetFill()) :
                    NsStaticCast<SolidColorBrush*>(mSelectedRectangle->GetStroke()));

                BindSelection();

                SetSelection();
            }
        }

        e.handled = true;
    }

    void ClearSelection()
    {
        if (mSelectedRectangle)
        {
            Canvas::SetLeft(mSelectedRectangle.GetPtr(), mLeft->GetValue());
            Canvas::SetTop(mSelectedRectangle.GetPtr(), mTop->GetValue());
            mSelectedRectangle->SetWidth(mWidth->GetValue());
            mSelectedRectangle->SetHeight(mHeight->GetValue());
            if (mFill->GetIsChecked().GetValue())
            {
                Ptr<Brush> fill = NsStaticCast<Ptr<Brush> >(mColorSelector->GetColor()->Clone());
                mSelectedRectangle->SetFill(fill.GetPtr());
            }
            else
            {
                Ptr<Brush> stroke = NsStaticCast<Ptr<Brush> >(mColorSelector->GetColor()->Clone());
                mSelectedRectangle->SetStroke(stroke.GetPtr());
            }

            mContainerCanvas->GetChildren()->Remove(mSelectionBorder.GetPtr());
        }
    }

    void BindSelection()
    {
        BaseComponent* source = 0;
        Ptr<Binding> binding;

        source = mLeft;
        binding = *new Binding("Value", source);
        BindingOperations::SetBinding(mSelectedRectangle.GetPtr(), Canvas::LeftProperty,
            binding.GetPtr());

        source = mTop;
        binding = *new Binding("Value", source);
        BindingOperations::SetBinding(mSelectedRectangle.GetPtr(), Canvas::TopProperty,
            binding.GetPtr());

        source = mWidth;
        binding = *new Binding("Value", source);
        BindingOperations::SetBinding(mSelectedRectangle.GetPtr(), FrameworkElement::WidthProperty,
            binding.GetPtr());

        source = mHeight;
        binding = *new Binding("Value", source);
        BindingOperations::SetBinding(mSelectedRectangle.GetPtr(), FrameworkElement::HeightProperty,
            binding.GetPtr());

        source = mColorSelector;
        binding = *new Binding("Color", source);
        BindingOperations::SetBinding(mSelectedRectangle.GetPtr(), mFill->GetIsChecked().GetValue() ?
            Shape::FillProperty : Shape::StrokeProperty, binding.GetPtr());
    }

    void BlendTutorialMainWindow::SetSelection()
    {
        Ptr<Border> selection = *new Border();
        selection->Init();

        BaseComponent* source = mSelectedRectangle.GetPtr();
        Ptr<Binding> binding;

        binding = *new Binding("Width", source);
        BindingOperations::SetBinding(selection.GetPtr(), FrameworkElement::WidthProperty,
            binding.GetPtr());
        binding = *new Binding("Height", source);
        BindingOperations::SetBinding(selection.GetPtr(), FrameworkElement::HeightProperty,
            binding.GetPtr());

        Ptr<Brush> borderBrush = NsStaticCast<Ptr<Brush> >(Brushes::Black()->Clone());
        borderBrush->SetOpacity(0.5f);

        mSelectionBorder = *new Border();
        mSelectionBorder->Init();
        mSelectionBorder->SetBorderBrush(borderBrush.GetPtr());
        mSelectionBorder->SetBorderThickness(Drawing::Thickness(2.0f));
        mSelectionBorder->SetCornerRadius(Drawing::CornerRadius(4.0f));
        mSelectionBorder->SetMargin(Drawing::Thickness(-3.0f, -3.0f, 0.0f, 0.0f));
        mSelectionBorder->SetPadding(Drawing::Thickness(2.0f, 2.0f, 0.0f, 0.0f));
        mSelectionBorder->SetChild(selection.GetPtr());

        binding = *new Binding("(Canvas.Left)", source);
        BindingOperations::SetBinding(mSelectionBorder.GetPtr(), Canvas::LeftProperty,
            binding.GetPtr());
        binding = *new Binding("(Canvas.Top)", source);
        BindingOperations::SetBinding(mSelectionBorder.GetPtr(), Canvas::TopProperty,
            binding.GetPtr());

        mContainerCanvas->GetChildren()->Add(mSelectionBorder.GetPtr());
    }

private:
    Border* mContainerBorder;
    Canvas* mContainerCanvas;

    Slider* mLeft;
    Slider* mTop;
    Slider* mWidth;
    Slider* mHeight;

    RadioButton* mFill;
    BlendTutorialColorSelector* mColorSelector;
    
    Ptr<Rectangle> mSelectedRectangle;
    Ptr<Border> mSelectionBorder;

    NS_IMPLEMENT_INLINE_REFLECTION(BlendTutorialMainWindow, Window)
    {
        NsMeta<TypeId>("BlendTutorial.MainWindow");

        NsFunc("AddButton_Click", &BlendTutorialMainWindow::AddButton_Click);
        NsFunc("RemoveButton_Click", &BlendTutorialMainWindow::RemoveButton_Click);
        NsFunc("RadioButton_Checked", &BlendTutorialMainWindow::RadioButton_Checked);
        NsFunc("ContainerBorder_PreviewMouseLeftButtonDown",
            &BlendTutorialMainWindow::ContainerBorder_PreviewMouseLeftButtonDown);
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
extern "C" NS_DLL_EXPORT void NsRegisterReflection(ComponentFactory* factory,
    NsBool registerComponents)
{
    NS_REGISTER_COMPONENT(BlendTutorialApp)
    NS_REGISTER_COMPONENT(BlendTutorialMainWindow)
    NS_REGISTER_COMPONENT(BlendTutorialColorSelector)
}