﻿#if !UNITY_EDITOR

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BlendTutorial
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private Rectangle SelectedRectangle = null;
		private Border SelectionBorder = null;
		
		public MainWindow()
		{
			this.InitializeComponent();
		}

		private void AddButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			ClearSelection();
			
			this.SelectedRectangle = new Rectangle();
			this.SelectedRectangle.Fill = Brushes.Red.Clone();
			this.SelectedRectangle.Stroke = Brushes.Transparent.Clone();
			this.SelectedRectangle.StrokeThickness = 5;

			this.LeftValue.Value = 0;
			this.TopValue.Value = 0;
			this.WidthValue.Value = 100;
			this.HeightValue.Value = 100;
			this.ColorSelectorControl.Color = Brushes.Red.Clone();

			BindSelection();
			
			this.ContainerCanvas.Children.Add(this.SelectedRectangle);

			SetSelection();
		}

		private void RemoveButton_Click(object sender, System.Windows.RoutedEventArgs e)
		{
			if (this.SelectedRectangle != null)
			{
				this.ContainerCanvas.Children.Remove(this.SelectedRectangle);
				this.ContainerCanvas.Children.Remove(this.SelectionBorder);
				
				this.SelectedRectangle = null;
				this.SelectionBorder = null;
			}
		}

		private void ContainerBorder_PreviewMouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			HitTestResult hr = VisualTreeHelper.HitTest(this.ContainerBorder, e.GetPosition(this.ContainerBorder));
			
			Rectangle newSelection = hr.VisualHit as Rectangle;
			if (newSelection != this.SelectedRectangle)
			{
				ClearSelection();
			
				this.SelectedRectangle = newSelection;
			
				if (this.SelectedRectangle != null)
				{
					this.LeftValue.Value = Canvas.GetLeft(this.SelectedRectangle);
					this.TopValue.Value = Canvas.GetTop(this.SelectedRectangle);
					this.WidthValue.Value = this.SelectedRectangle.Width;
					this.HeightValue.Value = this.SelectedRectangle.Height;
					this.ColorSelectorControl.Color = (this.FillRadioButton.IsChecked.Value ? this.SelectedRectangle.Fill : this.SelectedRectangle.Stroke) as SolidColorBrush;
				
					BindSelection();
				
					SetSelection();
				}
			}
			
			e.Handled = true;
		}
		
		private void RadioButton_Checked(object sender, System.Windows.RoutedEventArgs e)
		{
			if (this.SelectedRectangle != null)
			{
				if (this.FillRadioButton.IsChecked.Value)
				{
					this.SelectedRectangle.Stroke = this.ColorSelectorControl.Color.Clone();
					this.ColorSelectorControl.Color = this.SelectedRectangle.Fill as SolidColorBrush;
					Binding binding = new Binding("Color") { Source = this.ColorSelectorControl };
					this.SelectedRectangle.SetBinding(Shape.FillProperty, binding);
				}
				else
				{
					this.SelectedRectangle.Fill = this.ColorSelectorControl.Color.Clone();
					this.ColorSelectorControl.Color = this.SelectedRectangle.Stroke as SolidColorBrush;
					Binding binding = new Binding("Color") { Source = this.ColorSelectorControl };
					this.SelectedRectangle.SetBinding(Shape.StrokeProperty, binding);
				}
			}
		}

		private void ClearSelection()
		{
			if (this.SelectedRectangle != null)
			{
				Canvas.SetLeft(this.SelectedRectangle, this.LeftValue.Value);
				Canvas.SetTop(this.SelectedRectangle, this.TopValue.Value);
				this.SelectedRectangle.Width = this.WidthValue.Value;
				this.SelectedRectangle.Height = this.HeightValue.Value;
				if (this.FillRadioButton.IsChecked.Value)
				{
					this.SelectedRectangle.Fill = this.ColorSelectorControl.Color.Clone();
				}
				else
				{
					this.SelectedRectangle.Stroke = this.ColorSelectorControl.Color.Clone();
				}
				
				this.ContainerCanvas.Children.Remove(this.SelectionBorder);
			}
		}
		
		private void BindSelection()
		{
			Binding binding;
			
			binding = new Binding("Value") { Source = this.LeftValue };
			this.SelectedRectangle.SetBinding(Canvas.LeftProperty, binding);
			binding = new Binding("Value") { Source = this.TopValue };
			this.SelectedRectangle.SetBinding(Canvas.TopProperty, binding);
			binding = new Binding("Value") { Source = this.WidthValue };
			this.SelectedRectangle.SetBinding(FrameworkElement.WidthProperty, binding);
			binding = new Binding("Value") { Source = this.HeightValue };
			this.SelectedRectangle.SetBinding(FrameworkElement.HeightProperty, binding);
			binding = new Binding("Color") { Source = this.ColorSelectorControl };
			this.SelectedRectangle.SetBinding(this.FillRadioButton.IsChecked.Value ? Shape.FillProperty : Shape.StrokeProperty, binding);
		}
		
		private void SetSelection()
		{
			Border selection = new Border();
		
			Binding binding;
			
			binding = new Binding("Width") { Source = this.SelectedRectangle };
			selection.SetBinding(FrameworkElement.WidthProperty, binding);
			binding = new Binding("Height") { Source = this.SelectedRectangle };
			selection.SetBinding(FrameworkElement.HeightProperty, binding);

			this.SelectionBorder = new Border();
			this.SelectionBorder.BorderBrush = Brushes.Black.Clone();
			this.SelectionBorder.BorderBrush.Opacity = 0.5;
			this.SelectionBorder.BorderThickness = new Thickness(2);
			this.SelectionBorder.CornerRadius = new CornerRadius(4);
			this.SelectionBorder.Margin = new Thickness(-3, -3, 0, 0);
			this.SelectionBorder.Padding = new Thickness(2, 2, 0, 0);
			this.SelectionBorder.Child = selection;

			binding = new Binding("(Canvas.Left)") { Source = this.SelectedRectangle };
			this.SelectionBorder.SetBinding(Canvas.LeftProperty, binding);
			binding = new Binding("(Canvas.Top)") { Source = this.SelectedRectangle };
			this.SelectionBorder.SetBinding(Canvas.TopProperty, binding);

			this.ContainerCanvas.Children.Add(this.SelectionBorder);
		}
	}
}

#endif