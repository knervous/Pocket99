#pragma warning(disable: 4275)
#pragma warning(disable: 4251)


#include <Noesis.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/TypeId.h>
#include <NsCore/Package.h>
#include <NsDrawing/Color.h>
#include <NsGui/UserControl.h>
#include <NsGui/UIElementData.h>
#include <NsGui/FrameworkPropertyMetaData.h>
#include <NsGui/IntegrationAPI.h>
#include <NsGui/RoutedEvent.h>
#include <NsGui/SolidColorBrush.h>
#include <NsGui/Slider.h>


using namespace Noesis;
using namespace Noesis::Core;
using namespace Noesis::Drawing;
using namespace Noesis::Gui;


#define CONNECT_EVENT_HANDLER(type, event, handler) \
    if (String::Compare(eventName, #event) == 0 && String::Compare(handlerName, #handler) == 0) \
    { \
        ((type*)source)->event() += MakeDelegate(this, &SelfClass::handler); \
        return; \
    }

////////////////////////////////////////////////////////////////////////////////////////////////////
class NumericUpDown: public UserControl
{
public:
    NumericUpDown()
    {
        InitializeComponent();
    }

    /// Gets or sets numeric spinner value
    //@{
    NsInt32 GetValue() const
    {
        return DependencyObject::GetValue<NsInt32>(ValueProperty);
    }

    void SetValue(NsInt32 value)
    {
        DependencyObject::SetValue<NsInt32>(ValueProperty, value);
    }
    //@}

    /// Occurs when numeric value changes
    RoutedEvent_<RoutedPropertyChangedEventHandler<NsInt32>::Handler> ValueChanged()
    {
        return RoutedEvent_<RoutedPropertyChangedEventHandler<NsInt32>::Handler>(this,
            ValueChangedEvent);
    }

public:
    static const DependencyProperty* ValueProperty;
    static const DependencyProperty* MaxValueProperty;
    static const DependencyProperty* MinValueProperty;
    static const DependencyProperty* StepValueProperty;
    static const RoutedEvent* ValueChangedEvent;

protected:
    virtual void OnValueChanged(const RoutedPropertyChangedEventArgs<NsInt32>& args)
    {
        RaiseEvent(args);
    }

    /// From DependencyObject
    //@{
    NsBool OnPropertyChanged(const DependencyPropertyChangedEventArgs& args)
    {
        NsBool handled = ParentClass::OnPropertyChanged(args);

        if (!handled)
        {
            if (args.prop == ValueProperty)
            {
                NsInt32 oldValue = *static_cast<const NsInt32*>(args.oldValue);
                NsInt32 newValue = *static_cast<const NsInt32*>(args.newValue);

                RoutedPropertyChangedEventArgs<NsInt32> e(this, ValueChangedEvent,
                    oldValue, newValue);
                OnValueChanged(e);

                return true;
            }
        }

        return handled;
    }
    //@}

private:
    void InitializeComponent()
    {
        GUI::LoadComponent(this, "NumericUpDown.xaml");
    }

    void Connect(BaseComponent* source, const NsChar* eventName, const NsChar* handlerName)
    {
        CONNECT_EVENT_HANDLER(Button, Click, UpButton_Click);
        CONNECT_EVENT_HANDLER(Button, Click, DownButton_Click);
    }

    void UpButton_Click(BaseComponent* sender, const RoutedEventArgs& e)
    {
        NsInt32 step = DependencyObject::GetValue<NsInt32>(StepValueProperty);
        SetValue(GetValue() + step);
    }

    void DownButton_Click(BaseComponent* sender, const RoutedEventArgs& e)
    {
        NsInt32 step = DependencyObject::GetValue<NsInt32>(StepValueProperty);
        SetValue(GetValue() - step);
    }
    
    static NsBool CoerceValue(const DependencyObject* object, const void* value, void* coercedValue)
    {
        NsInt32 maxValue = object->GetValue<NsInt32>(MaxValueProperty);
        NsInt32 minValue = object->GetValue<NsInt32>(MinValueProperty);
    
        NsInt32 newValue = *static_cast<const NsInt32*>(value);
        NsInt32& coerced = *static_cast<NsInt32*>(coercedValue);

        coerced = Math::Clip(newValue, minValue, maxValue);
        return true;
    }

    NS_IMPLEMENT_INLINE_REFLECTION(NumericUpDown, UserControl)
    {
        NsMeta<TypeId>("NumericUpDown");

        Ptr<UIElementData> data = NsMeta<UIElementData>(TypeOf<SelfClass>());
        data->RegisterProperty<NsInt32>(ValueProperty, "Value",
            FrameworkPropertyMetadata::Create(NsInt32(0), &CoerceValue));
        data->RegisterProperty<NsInt32>(MaxValueProperty, "MaxValue",
            FrameworkPropertyMetadata::Create(NsInt32(255), FrameworkOptions_None));
        data->RegisterProperty<NsInt32>(MinValueProperty, "MinValue",
            FrameworkPropertyMetadata::Create(NsInt32(0), FrameworkOptions_None));
        data->RegisterProperty<NsInt32>(StepValueProperty, "StepValue",
            FrameworkPropertyMetadata::Create(NsInt32(1), FrameworkOptions_None));

        data->RegisterEvent(ValueChangedEvent, "ValueChanged", RoutingStrategy_Bubbling);
    }
};

const DependencyProperty* NumericUpDown::ValueProperty;
const DependencyProperty* NumericUpDown::MaxValueProperty;
const DependencyProperty* NumericUpDown::MinValueProperty;
const DependencyProperty* NumericUpDown::StepValueProperty;
const RoutedEvent* NumericUpDown::ValueChangedEvent;

////////////////////////////////////////////////////////////////////////////////////////////////////
// This code-behind class is needed because MultiBindings are not supported by NoesisGUI v1.0
// http://stackoverflow.com/questions/1978316/binding-r-g-b-properties-of-color-in-wpf
// Then we have to do it manually
///////////////////////////////////////////////////////////////////////////////////////////////////

#include <NsGui/Grid.h>

////////////////////////////////////////////////////////////////////////////////////////////////////
class MultiBinding: public Grid
{
public:
    MultiBinding()
    {
        InitializeComponent();
    }

private:
    void InitializeComponent()
    {
        GUI::LoadComponent(this, "sample.xaml");
    }

    void Connect(BaseComponent* source, const NsChar* eventName, const NsChar* handlerName)
    {
        CONNECT_EVENT_HANDLER(NumericUpDown, ValueChanged, BgR_ValueChanged);
        CONNECT_EVENT_HANDLER(NumericUpDown, ValueChanged, BgG_ValueChanged);
        CONNECT_EVENT_HANDLER(NumericUpDown, ValueChanged, BgB_ValueChanged);
        CONNECT_EVENT_HANDLER(NumericUpDown, ValueChanged, FgR_ValueChanged);
        CONNECT_EVENT_HANDLER(NumericUpDown, ValueChanged, FgG_ValueChanged);
        CONNECT_EVENT_HANDLER(NumericUpDown, ValueChanged, FgB_ValueChanged);
    }

    void BgR_ValueChanged(BaseComponent*, const RoutedPropertyChangedEventArgs<NsInt32>& args)
    {
        SolidColorBrush* bg = FindName<SolidColorBrush>("BgColor");
        Color color = bg->GetColor();
        bg->SetColor(Color(args.newValue, color.GetGreenI(), color.GetBlueI(), color.GetAlphaI()));
    }
    
    void BgG_ValueChanged(BaseComponent*, const RoutedPropertyChangedEventArgs<NsInt32>& args)
    {
        SolidColorBrush* bg = FindName<SolidColorBrush>("BgColor");
        Color color = bg->GetColor();
        bg->SetColor(Color(color.GetRedI(), args.newValue, color.GetBlueI(), color.GetAlphaI()));
    }
    
    void BgB_ValueChanged(BaseComponent*, const RoutedPropertyChangedEventArgs<NsInt32>& args)
    {
        SolidColorBrush* bg = FindName<SolidColorBrush>("BgColor");
        Color color = bg->GetColor();
        bg->SetColor(Color(color.GetRedI(), color.GetGreenI(), args.newValue, color.GetAlphaI()));
    }
    
    void FgR_ValueChanged(BaseComponent*, const RoutedPropertyChangedEventArgs<NsInt32>& args)
    {
        SolidColorBrush* fg = FindName<SolidColorBrush>("FgColor");
        Color color = fg->GetColor();
        fg->SetColor(Color(args.newValue, color.GetGreenI(), color.GetBlueI(), color.GetAlphaI()));
    }
    
    void FgG_ValueChanged(BaseComponent*, const RoutedPropertyChangedEventArgs<NsInt32>& args)
    {
        SolidColorBrush* fg = FindName<SolidColorBrush>("FgColor");
        Color color = fg->GetColor();
        fg->SetColor(Color(color.GetRedI(), args.newValue, color.GetBlueI(), color.GetAlphaI()));
    }
    
    void FgB_ValueChanged(BaseComponent*, const RoutedPropertyChangedEventArgs<NsInt32>& args)
    {
        SolidColorBrush* fg = FindName<SolidColorBrush>("FgColor");
        Color color = fg->GetColor();
        fg->SetColor(Color(color.GetRedI(), color.GetGreenI(), args.newValue, color.GetAlphaI()));
    }

    NS_IMPLEMENT_INLINE_REFLECTION(MultiBinding, Grid)
    {
        NsMeta<TypeId>("MultiBinding");
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
extern "C" NS_DLL_EXPORT
void NsRegisterReflection(ComponentFactory* factory, NsBool registerComponents)
{
    NS_REGISTER_COMPONENT(NumericUpDown)
    NS_REGISTER_COMPONENT(MultiBinding)
}