#pragma warning(disable: 4275)
#pragma warning(disable: 4251)


#include <Noesis.h>
#include <NsGui/Control.h>
#include <NsGui/UIElementData.h>
#include <NsGui/FrameworkPropertyMetaData.h>
#include <NsGui/ResourceKeyType.h>
#include <NsCore/ReflectionImplement.h>
#include <NsCore/TypeId.h>
#include <NsCore/Package.h>

#include <NsGui/BaseValueConverter.h>
#include <NsCore/Boxing.h>


using namespace Noesis;
using namespace Noesis::Core;
using namespace Noesis::Core::Boxing;
using namespace Noesis::Gui;


////////////////////////////////////////////////////////////////////////////////////////////////////
class DateTime: public Control
{
public:
    /// Gets or sets day
    //@{
    NsInt32 GetDay() const
    {
        return GetValue<NsInt32>(DayProperty);
    }
    void SetDay(NsInt32 day)
    {
        SetValue<NsInt32>(DayProperty, day);
    }
    //@}

    /// Gets or sets month
    //@{
    NsInt32 GetMonth() const
    {
        return GetValue<NsInt32>(MonthProperty);
    }
    void SetMonth(NsInt32 month)
    {
        SetValue<NsInt32>(MonthProperty, month);
    }
    //@}

    /// Gets or sets year
    //@{
    NsInt32 GetYear() const
    {
        return GetValue<NsInt32>(YearProperty);
    }
    void SetYear(NsInt32 year)
    {
        SetValue<NsInt32>(YearProperty, year);
    }
    //@}

    /// Gets or sets hour
    //@{
    NsInt32 GetHour() const
    {
        return GetValue<NsInt32>(HourProperty);
    }
    void SetHour(NsInt32 hour)
    {
        SetValue<NsInt32>(HourProperty, hour);
    }
    //@}

    /// Gets or sets minute
    //@{
    NsInt32 GetMinute() const
    {
        return GetValue<NsInt32>(MinuteProperty);
    }
    void SetMinute(NsInt32 minute)
    {
        SetValue<NsInt32>(MinuteProperty, minute);
    }
    //@}

    /// Gets or sets second
    //@{
    NsInt32 GetSecond() const
    {
        return GetValue<NsInt32>(SecondProperty);
    }
    void SetSecond(NsInt32 second)
    {
        SetValue<NsInt32>(SecondProperty, second);
    }
    //@}

public:
    static const Gui::DependencyProperty* DayProperty;
    static const Gui::DependencyProperty* MonthProperty;
    static const Gui::DependencyProperty* YearProperty;
    static const Gui::DependencyProperty* HourProperty;
    static const Gui::DependencyProperty* MinuteProperty;
    static const Gui::DependencyProperty* SecondProperty;

    NS_IMPLEMENT_INLINE_REFLECTION(DateTime, Control)
    {
        NsMeta<TypeId>("DateTime");

        //NsProp("Day", &DateTime::GetDay, &DateTime::SetDay);
        //NsProp("Month", &DateTime::GetMonth, &DateTime::SetMonth);
        //NsProp("Year", &DateTime::GetYear, &DateTime::SetYear);
        //NsProp("Hour", &DateTime::GetHour, &DateTime::SetHour);
        //NsProp("Minute", &DateTime::GetMinute, &DateTime::SetMinute);
        //NsProp("Second", &DateTime::GetSecond, &DateTime::SetSecond);

        const TypeClass* type = TypeOf<SelfClass>();
        Ptr<ResourceKeyType> defaultStyleKey = ResourceKeyType::Create(type);

        Ptr<UIElementData> data = NsMeta<UIElementData>(type);
        data->RegisterProperty<NsInt32>(DayProperty, "Day",
            FrameworkPropertyMetadata::Create(NsInt32(1), FrameworkOptions_None));
        data->RegisterProperty<NsInt32>(MonthProperty, "Month",
            FrameworkPropertyMetadata::Create(NsInt32(1), FrameworkOptions_None));
        data->RegisterProperty<NsInt32>(YearProperty, "Year",
            FrameworkPropertyMetadata::Create(NsInt32(2000), FrameworkOptions_None));
        data->RegisterProperty<NsInt32>(HourProperty, "Hour",
            FrameworkPropertyMetadata::Create(NsInt32(0), FrameworkOptions_None));
        data->RegisterProperty<NsInt32>(MinuteProperty, "Minute",
            FrameworkPropertyMetadata::Create(NsInt32(0), FrameworkOptions_None));
        data->RegisterProperty<NsInt32>(SecondProperty, "Second",
            FrameworkPropertyMetadata::Create(NsInt32(0), FrameworkOptions_None));
        data->OverrideMetadata<Ptr<ResourceKeyType> >(FrameworkElement::DefaultStyleKeyProperty,
            "DefaultStyleKey", FrameworkPropertyMetadata::Create(defaultStyleKey,
            FrameworkOptions_None));
    }
};

const DependencyProperty* DateTime::DayProperty;
const DependencyProperty* DateTime::MonthProperty;
const DependencyProperty* DateTime::YearProperty;
const DependencyProperty* DateTime::HourProperty;
const DependencyProperty* DateTime::MinuteProperty;
const DependencyProperty* DateTime::SecondProperty;

////////////////////////////////////////////////////////////////////////////////////////////////////
class HoursConverter: public BaseValueConverter
{
public:
    NsBool TryConvert(BaseComponent* value, const Type* targetType, BaseComponent* parameter,
        Ptr<Core::BaseComponent>& result)
    {
        NS_ASSERT(targetType == TypeOf<NsFloat32>());
        NsInt32 hour = Unbox<NsInt32>(NsStaticCast<BoxedValue*>(value));
        result = Boxing::Box<NsFloat32>(hour * 30.0f);
        return true;
    }

    NS_IMPLEMENT_INLINE_REFLECTION(HoursConverter, BaseValueConverter)
    {
        NsMeta<TypeId>("HoursConverter");
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
class MinutesConverter: public BaseValueConverter
{
public:
    NsBool TryConvert(BaseComponent* value, const Type* targetType, BaseComponent* parameter,
        Ptr<Core::BaseComponent>& result)
    {
        NS_ASSERT(targetType == TypeOf<NsFloat32>());
        NsInt32 hour = Unbox<NsInt32>(NsStaticCast<BoxedValue*>(value));
        result = Boxing::Box<NsFloat32>(hour * 6.0f);
        return true;
    }

    NS_IMPLEMENT_INLINE_REFLECTION(MinutesConverter, BaseValueConverter)
    {
        NsMeta<TypeId>("MinutesConverter");
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
class SecondsConverter: public BaseValueConverter
{
public:
    NsBool TryConvert(BaseComponent* value, const Type* targetType, BaseComponent* parameter,
        Ptr<Core::BaseComponent>& result)
    {
        NS_ASSERT(targetType == TypeOf<NsFloat32>());
        NsInt32 hour = Unbox<NsInt32>(NsStaticCast<BoxedValue*>(value));
        result = Boxing::Box<NsFloat32>(hour * 6.0f);
        return true;
    }

    NS_IMPLEMENT_INLINE_REFLECTION(SecondsConverter, BaseValueConverter)
    {
        NsMeta<TypeId>("SecondsConverter");
    }
};

////////////////////////////////////////////////////////////////////////////////////////////////////
extern "C" NS_DLL_EXPORT void NsRegisterReflection(ComponentFactory* factory,
    NsBool registerComponents)
{
    NS_REGISTER_COMPONENT(DateTime)
    NS_REGISTER_COMPONENT(HoursConverter)
    NS_REGISTER_COMPONENT(MinutesConverter)
    NS_REGISTER_COMPONENT(SecondsConverter)
}
